KBD.COM
ist ein kleiner deutscher Tastaturtreiber f�r DOS,
der auch unter Windows geladen werden kann und ohne 
Einschr�nkungen funktioniert. Im Gegensatz zu dem
in DOS bereits vorhandenen Treiber KEYB.COM ben�tigt
KBD.COM nur ca. 1 kb im Speicher.

Installation:
Kopieren Sie KBD.COM nach dem Entpacken in das
Verzeichnis WINDOWS\COMMAND bzw. in das Verzeichnis,
in dem sich KEYB.COM befindet (nein, es wird nicht
gel�scht). �ndern Sie in Ihrer AUTOEXEC.BAT den
Aufruf
KEYB GR...
in 
KBD (ohne jeden Zusatz)

Wenn Sie den Treiber nicht in der AUTOEXEC.BAT
laden wollen (f�r Windows nicht erforderlich),
k�nnen Sie ihn in einem DOS-Fenster von Windows
dennoch benutzen, wenn Sie die Verkn�pfung f�r
die "MSDOS-Eingabeaufforderung" mit der rechten
Maustaste anklicken, "Eigenschaften" w�hlen und 
auf der Registerkarte "Programm" in das Feld
"Stapelverarbeitungsdatei:" KBD.COM eintragen.

Dies gilt analog f�r andere Verkn�pfungen zu
MSDOS-Programmen.
